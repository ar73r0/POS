from . import res_partner
from . import event_sync